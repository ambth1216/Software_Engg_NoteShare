const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Note = require('../models/Note');
const { protect } = require('../middleware/auth');

// Check if AWS S3 environment variables are provided
const isS3Enabled = process.env.USE_S3 === 'true' || !!process.env.AWS_S3_BUCKET_NAME;

let storage;

if (isS3Enabled) {
  try {
    const { S3Client } = require('@aws-sdk/client-s3');
    const multerS3 = require('multer-s3');

    const s3 = new S3Client({
      region: process.env.AWS_REGION || 'us-east-1',
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
    });

    storage = multerS3({
      s3: s3,
      bucket: process.env.AWS_S3_BUCKET_NAME,
      metadata: function (req, file, cb) {
        cb(null, { fieldName: file.fieldname });
      },
      key: function (req, file, cb) {
        cb(null, `notes/${Date.now()}_${path.basename(file.originalname)}`);
      },
    });
    console.log('AWS S3 Storage engine initialized successfully.');
  } catch (err) {
    console.error('Failed to initialize AWS S3 storage engine, falling back to local disk storage:', err.message);
    storage = multer.diskStorage({
      destination: './uploads',
      filename: function (req, file, cb) {
        cb(null, `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`);
      },
    });
  }
} else {
  // Local disk storage engine
  storage = multer.diskStorage({
    destination: './uploads',
    filename: function (req, file, cb) {
      cb(null, `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`);
    },
  });
}

// Upload middleware setup
const upload = multer({
  storage: storage,
  limits: { fileSize: 10000000 }, // 10MB limit
  fileFilter: function (req, file, cb) {
    const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt|ppt|pptx/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb('Error: Files of this type are not allowed!');
    }
  },
}).single('file');

// Upload notes route
router.post('/upload', protect, (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      console.log(err);
      return res.status(400).json({ success: false, message: typeof err === 'string' ? err : err.message });
    }

    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Please upload a file' });
    }

    const { title, subject } = req.body;
    if (!title || !subject) {
      return res.status(400).json({ success: false, message: 'Please provide title and subject' });
    }

    try {
      // Determine file URL & path depending on S3 vs local storage
      const fileUrl = req.file.location
        ? req.file.location
        : `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;

      const storedFilePath = req.file.location || req.file.key || req.file.path;

      const newNote = await Note.create({
        title,
        subject,
        viewUrl: fileUrl,
        filePath: storedFilePath,
        originalFileName: req.file.originalname,
        uploader: req.user.id,
        uploaderName: req.user.name,
        uploaderRole: req.user.role,
      });

      res.status(201).json({
        success: true,
        data: newNote,
      });
    } catch (dbErr) {
      console.error(dbErr);
      res.status(500).json({ success: false, message: 'Server Error' });
    }
  });
});

// Route to get notes from DB with filtering & pagination
router.get('/', async (req, res) => {
  try {
    let query = {};
    if (req.query.role === 'teacher') {
      query.uploaderRole = 'teacher';
      query.verified = true;
    }

    if (req.query.subject) {
      query.subject = req.query.subject;
    }

    if (req.query.q) {
      query.$text = { $search: req.query.q };
    }

    let sortOptions = {};
    switch (req.query.sort) {
      case 'rating':
        sortOptions = { rating: -1 };
        break;
      case 'title':
        sortOptions = { title: 1 };
        break;
      case 'recent':
      default:
        sortOptions = { createdAt: -1 };
        break;
    }

    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 9;
    const startIndex = (page - 1) * limit;

    const total = await Note.countDocuments(query);

    const notes = await Note.find(query)
      .sort(sortOptions)
      .skip(startIndex)
      .limit(limit);

    res.status(200).json({
      success: true,
      total,
      count: notes.length,
      page,
      pages: Math.ceil(total / limit),
      notes: notes,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

// Download note route
router.get('/download/:id', async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) {
      return res.status(404).json({ success: false, message: 'Note not found' });
    }

    // Check if the file is stored in S3 (URL string)
    if (note.filePath.startsWith('http://') || note.filePath.startsWith('https://') || (note.viewUrl && note.viewUrl.startsWith('http') && !note.viewUrl.includes('/uploads/'))) {
      return res.redirect(note.viewUrl || note.filePath);
    }

    // Local file download logic
    const filePath = path.join(__dirname, '..', note.filePath);
    const originalName = note.originalFileName;

    res.download(filePath, originalName, (err) => {
      if (err) {
        console.error("File download error:", err);
        if (!res.headersSent) {
          res.status(404).json({ success: false, message: 'File not found on server.' });
        }
      }
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

module.exports = router;